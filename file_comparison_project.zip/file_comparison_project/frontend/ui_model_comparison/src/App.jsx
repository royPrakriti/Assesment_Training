import { useEffect, useState } from "react";

import Navbar from "./components/Navbar";
import QuestionInput from "./components/QuestionInput";
import ModelCard from "./components/ModelCard";
import ComparisonChart from "./components/ComparisonChart";
import TokenChart from "./components/TokenChart";
import StatusChart from "./components/StatusChart";
import SourcePanel from "./components/SourcePanel";
import HistoricalChart from "./components/HistoricalChart";

import { compareModels, checkBackend } from "./services/api";

import {
    Zap,
    Clock,
    Activity,
    Trophy,
    BrainCircuit,
    LoaderCircle
} from "lucide-react";

import "./App.css";

function App() {

    const [question, setQuestion] = useState("");
    const [results, setResults] = useState({});
    const [sources, setSources] = useState([]);

    const [loading, setLoading] = useState(false);
    const [connected, setConnected] = useState(false);
    const [error, setError] = useState("");

    const [fastestModel, setFastestModel] = useState(null);

    const [history, setHistory] = useState([]);

    // Check backend connection
    useEffect(() => {

        const checkConnection = async () => {
            try {
                await checkBackend();
                setConnected(true);
            } catch {
                setConnected(false);
            }
        };

        checkConnection();

    }, []);

    // Calculate dashboard statistics
    const modelResults = Object.values(results);

    const successfulResults = modelResults.filter(
        result =>
            result.status === "success" &&
            result.answer
    );

    const averageLatency = successfulResults.length
        ? (
            successfulResults.reduce(
                (total, result) =>
                    total + result.response_time,
                0
            ) / successfulResults.length
        ).toFixed(2)
        : "—";

    // Submit question to backend
    const handleCompare = async () => {

        if (!question.trim()) return;

        setLoading(true);
        setError("");
        setResults({});
        setSources([]);
        setFastestModel(null);

        try {

            const data = await compareModels(question, 4);

            setResults(data.models || {});
            setSources(data.sources || []);
            setFastestModel(data.fastest_model);

            // Store latency history for successful models
            const successful = Object.entries(data.models || {})
                .filter(([_, result]) =>
                    result.status === "success" &&
                    result.answer
                );

            if (successful.length > 0) {

                setHistory(previous => [
                    ...previous,
                    {
                        run: `Q${previous.length + 1}`,
                        llama: data.models.llama?.status === "success"
                            ? data.models.llama.response_time
                            : null,
                        nemotron: data.models.nemotron?.status === "success"
                            ? data.models.nemotron.response_time
                            : null,
                        dots: data.models.dots?.status === "success"
                            ? data.models.dots.response_time
                            : null
                    }
                ]);
            }

        } catch (err) {

            setError(
                err.response?.data?.detail ||
                "Unable to connect to the backend. Please check FastAPI."
            );

        } finally {

            setLoading(false);

        }
    };

    return (

        <div className="app-container">

            <Navbar connected={connected} />

            <main className="dashboard">

                {/* Hero section */}
                <section className="hero-section">

                    <div className="hero-tag">
                        <BrainCircuit size={16} />
                        RETRIEVAL AUGMENTED GENERATION
                    </div>

                    <h1>
                        Compare <span>Intelligence.</span>
                    </h1>

                    <p>
                        One question. Three language models.
                        Discover the difference in speed and responses.
                    </p>

                </section>

                {/* Question input */}
                <QuestionInput
                    question={question}
                    setQuestion={setQuestion}
                    onCompare={handleCompare}
                    loading={loading}
                />

                {error && (
                    <div className="error-message">
                        {error}
                    </div>
                )}

                {/* Loading */}
                {loading && (
                    <div className="loading-section">
                        <LoaderCircle className="loader" size={28} />
                        <h3>Comparing three models...</h3>
                        <p>Retrieving documents and generating answers.</p>
                    </div>
                )}

                {/* Dashboard results */}
                {Object.keys(results).length > 0 && (

                    <>

                        <section className="stats-grid">

                            <div className="stat-card">
                                <div className="stat-icon">
                                    <Trophy />
                                </div>

                                <span>Fastest Model</span>

                                <h2>{fastestModel || "—"}</h2>
                            </div>

                            <div className="stat-card">
                                <div className="stat-icon">
                                    <Clock />
                                </div>

                                <span>Average Latency</span>

                                <h2>{averageLatency} s</h2>
                            </div>

                            <div className="stat-card">
                                <div className="stat-icon">
                                    <Activity />
                                </div>

                                <span>Successful Responses</span>

                                <h2>
                                    {successfulResults.length}/3
                                </h2>
                            </div>

                            <div className="stat-card">
                                <div className="stat-icon">
                                    <Zap />
                                </div>

                                <span>Comparison Runs</span>

                                <h2>{history.length}</h2>
                            </div>

                        </section>

                        {/* Model response cards */}
                        <section className="content-section">

                            <div className="section-title">
                                <h2>Model Responses</h2>
                                <span>Same question · Same context</span>
                            </div>

                            <div className="models-grid">

                                {["llama", "nemotron", "dots"].map(model => (

                                    <ModelCard
                                        key={model}
                                        model={model}
                                        result={results[model] || {}}
                                        fastest={fastestModel === model}
                                    />

                                ))}

                            </div>

                        </section>

                        {/* Charts */}
                        <section className="content-section">

                            <div className="section-title">
                                <h2>Performance Analytics</h2>
                                <span>Live comparison metrics</span>
                            </div>

                            <div className="charts-grid">

                                <ComparisonChart results={results} />

                                <TokenChart results={results} />

                                <StatusChart results={results} />

                            </div>

                        </section>

                        {/* Historical chart */}
                        <section className="content-section">

                            <div className="section-title">
                                <h2>Historical Performance</h2>
                                <span>Response time across questions</span>
                            </div>

                            <HistoricalChart history={history} />

                        </section>

                        {/* Sources */}
                        <section className="content-section">

                            <SourcePanel sources={sources} />

                        </section>

                    </>

                )}

                {/* Empty state */}
                {!loading && Object.keys(results).length === 0 && !error && (

                    <div className="empty-state">
                        <BrainCircuit size={48} />

                        <h2>Ready to compare?</h2>

                        <p>
                            Ask a question about your uploaded company
                            documents to begin your model comparison.
                        </p>
                    </div>

                )}

                <footer>
                    MODEL ARENA · MULTI-LLM RAG BENCHMARK
                </footer>

            </main>

        </div>
    );
}

export default App;