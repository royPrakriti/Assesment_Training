
import api from "./api";

export async function addExpense(expenseData) {
  const response = await api.post("/expenses", expenseData);
  return response.data;
}

export async function getExpenses(filters = {}) {
  const response = await api.get("/expenses", {
    params: filters,
  });
  return response.data;
}

export async function getCategories() {
  const response = await api.get("/categories");
  return response.data;
}
