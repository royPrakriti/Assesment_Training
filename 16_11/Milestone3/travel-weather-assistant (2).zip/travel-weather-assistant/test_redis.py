
import redis

client = redis.Redis(
    host="127.0.0.1",
    port=6379,
    decode_responses=True
)

try:
    print("Redis connection:", client.ping())

    client.set("project", "Travel Weather Assistant")

    value = client.get("project")

    print("Stored value:", value)

except redis.exceptions.RedisError as error:
    print("Redis error:", error)
