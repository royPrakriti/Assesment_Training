import { FileText } from "lucide-react";

function SourcePanel({ sources = [] }) {

    return (
        <div className="source-panel">

            <h3>
                <FileText size={19} />
                Retrieved Sources
            </h3>

            {sources.length > 0 ? (
                sources.map((source, index) => (
                    <div className="source-item" key={index}>
                        <FileText size={17} />
                        <span>{source}</span>
                    </div>
                ))
            ) : (
                <p>No sources available yet.</p>
            )}

        </div>
    );
}

export default SourcePanel;