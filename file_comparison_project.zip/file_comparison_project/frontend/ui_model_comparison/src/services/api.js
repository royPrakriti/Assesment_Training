import axios from "axios";

const API = axios.create({
    baseURL: "http://127.0.0.1:8000/api",
    headers: {
        "Content-Type": "application/json"
    },
    timeout: 180000
});

// Check backend connection
export const checkBackend = async () => {
    const response = await API.get("/health");
    return response.data;
};

// Send question and compare all three models
export const compareModels = async (question, top_k = 4) => {
    const response = await API.post("/compare", {
        question,
        top_k
    });

    return response.data;
};

export default API;