import { Search, Sparkles } from "lucide-react";

function QuestionInput({
    question,
    setQuestion,
    onCompare,
    loading
}) {
    const handleSubmit = (e) => {
        e.preventDefault();

        if (question.trim()) {
            onCompare();
        }
    };

    return (
        <div className="question-section">

            <div className="section-heading">
                <Sparkles size={20} />
                <span>ASK YOUR DOCUMENTS</span>
            </div>

            <form onSubmit={handleSubmit}>

                <textarea
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    placeholder="Ask anything about company policies or IT support..."
                    rows={3}
                />

                <div className="question-footer">

                    <span>Powered by RAG + 3 LLMs</span>

                    <button
                        type="submit"
                        disabled={loading || !question.trim()}
                    >
                        <Search size={17} />

                        {loading ? "Comparing..." : "Compare Models"}
                    </button>

                </div>

            </form>
        </div>
    );
}

export default QuestionInput;