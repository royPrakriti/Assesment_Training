
from langchain.tools import tool

from app.database.database import SessionLocal
from app.database.models import Trip


@tool
def get_saved_trip(trip_id: str) -> dict:
    """
    Retrieve a previously registered employee trip
    from the SQLite database using its trip ID.
    """

    db = SessionLocal()

    try:
        trip = db.query(Trip).filter(
            Trip.trip_id == trip_id
        ).first()

        if not trip:
            return {
                "success": False,
                "message": "Trip not found."
            }

        return {
            "success": True,
            "trip_id": trip.trip_id,
            "employee_id": trip.employee_id,
            "destination": trip.destination,
            "start_date": str(trip.start_date),
            "end_date": str(trip.end_date),
            "purpose": trip.purpose,
            "status": trip.status
        }

    finally:
        db.close()
