
import { useEffect, useState } from "react";
import { getExpenses } from "../services/expenseService";

function Transactions() {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  async function loadExpenses() {
    setLoading(true);
    setError("");

    try {
      const data = await getExpenses();
      setExpenses(Array.isArray(data) ? data : data.expenses ?? []);
    } catch {
      setError("Unable to load transactions. Check your backend connection.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadExpenses();
  }, []);

  const filteredExpenses = expenses.filter((expense) =>
    `${expense.description ?? ""} ${expense.category_name ?? ""}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <section>
      <div className="page-heading">
        <div>
          <h1>Transactions</h1>
          <p>Review your expenses and identify flagged transactions.</p>
        </div>
      </div>

      <div className="content-card">
        <input
          type="search"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search by description or category"
          aria-label="Search transactions"
        />

        {loading ? (
          <p>Loading transactions...</p>
        ) : error ? (
          <p className="error-message">{error}</p>
        ) : filteredExpenses.length === 0 ? (
          <p>No transactions found.</p>
        ) : (
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Description</th>
                  <th>Category</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {filteredExpenses.map((expense) => (
                  <tr key={expense.id}>
                    <td>{expense.expense_date}</td>
                    <td>{expense.description}</td>
                    <td>{expense.category_name ?? expense.category ?? "—"}</td>
                    <td>
                      ₹{Number(expense.amount ?? 0).toLocaleString("en-IN")}
                    </td>
                    <td>
                      {expense.is_flagged ? (
                        <span className="status-flagged">
                          Flagged
                          {expense.anomaly_reasons?.length
                            ? `: ${expense.anomaly_reasons.join(", ")}`
                            : ""}
                        </span>
                      ) : (
                        <span className="status-normal">Normal</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}

export default Transactions;
