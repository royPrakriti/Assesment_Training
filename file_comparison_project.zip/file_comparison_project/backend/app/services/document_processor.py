import os
import tiktoken

from app.core.config import CHUNK_SIZE, CHUNK_OVERLAP


# Initialize tokenizer
tokenizer = tiktoken.get_encoding("cl100k_base")


def load_documents(data_path):

    documents = []

    for filename in os.listdir(data_path):

        if filename.endswith(".txt"):

            file_path = os.path.join(data_path, filename)

            with open(file_path, "r", encoding="utf-8") as file:
                text = file.read()

            documents.append({
                "filename": filename,
                "content": text
            })

    return documents


def chunk_text(text):

    tokens = tokenizer.encode(text)

    chunks = []

    start = 0

    while start < len(tokens):

        end = start + CHUNK_SIZE

        chunk_tokens = tokens[start:end]

        chunk_text = tokenizer.decode(chunk_tokens)

        chunks.append(chunk_text)

        start += CHUNK_SIZE - CHUNK_OVERLAP

    return chunks


def process_documents(data_path):

    documents = load_documents(data_path)

    processed_chunks = []

    for document in documents:

        chunks = chunk_text(document["content"])

        for index, chunk in enumerate(chunks):

            processed_chunks.append({
                "text": chunk,
                "source": document["filename"],
                "chunk_id": index
            })

    return processed_chunks