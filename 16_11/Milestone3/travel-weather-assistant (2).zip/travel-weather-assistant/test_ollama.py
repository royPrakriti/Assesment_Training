
from langchain_ollama import ChatOllama

llm = ChatOllama(
    model="qwen2.5:3b",
    base_url="http://localhost:11434",
    temperature=0.2
)

response = llm.invoke(
    "Explain the purpose of a business travel assistant in two sentences."
)

print("\n--- OLLAMA RESPONSE ---")
print(response.content)
