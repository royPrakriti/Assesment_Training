import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer
} from "recharts";

function HistoricalChart({ history }) {

    return (
        <div className="chart-card">

            <h3>Response Time Trends</h3>

            <p>Latency across previous comparison runs</p>

            <div className="chart-container">

                <ResponsiveContainer width="100%" height="100%">

                    <LineChart data={history}>

                        <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="#333"
                        />

                        <XAxis
                            dataKey="run"
                            stroke="#aaa"
                        />

                        <YAxis
                            stroke="#aaa"
                            unit="s"
                        />

                        <Tooltip />

                        <Legend />

                        <Line
                            type="monotone"
                            dataKey="llama"
                            name="Llama 3.2"
                            stroke="#facc15"
                            strokeWidth={3}
                            connectNulls={false}
                        />

                        <Line
                            type="monotone"
                            dataKey="nemotron"
                            name="Nemotron"
                            stroke="#38bdf8"
                            strokeWidth={3}
                            connectNulls={false}
                        />

                        <Line
                            type="monotone"
                            dataKey="dots"
                            name="Dots"
                            stroke="#a78bfa"
                            strokeWidth={3}
                            connectNulls={false}
                        />

                    </LineChart>

                </ResponsiveContainer>

            </div>

        </div>
    );
}

export default HistoricalChart;