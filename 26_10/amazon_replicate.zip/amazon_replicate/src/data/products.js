const products = [
  { id: 1, name: "Wireless Headphones", category: "Electronics", price: 1499, image: "https://pngpix.com/images/hd/headphones-on-white-background-clipart-png-29-3gdxn0ftylxw3l68.jpg" },
  { id: 2, name: "Smart Watch", category: "Electronics", price: 2199, image: "https://wallpaperaccess.com/full/3021129.jpg" },
  { id: 3, name: "Running Shoes", category: "Fashion", price: 1799, image: "https://placehold.co/400x300?text=Shoes" },
  { id: 4, name: "Travel Backpack", category: "Fashion", price: 999, image: "https://placehold.co/400x300?text=Backpack" },
  { id: 5, name: "Bluetooth Speaker", category: "Electronics", price: 1299, image: "https://placehold.co/400x300?text=Speaker" },
  { id: 6, name: "Water Bottle", category: "Home", price: 499, image: "https://placehold.co/400x300?text=Bottle" },
  { id: 7, name: "Desk Lamp", category: "Home", price: 899, image: "https://placehold.co/400x300?text=Desk+Lamp" },
  { id: 8, name: "Cotton T-Shirt", category: "Fashion", price: 599, image: "https://placehold.co/400x300?text=T-Shirt" },
];
 
export default products;