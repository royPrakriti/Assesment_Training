npm create vite@latest event-enrollment -- --template react
npm install react-router-dom
