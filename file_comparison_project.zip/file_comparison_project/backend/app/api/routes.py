from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.comparison_service import run_comparison

router = APIRouter()


class ComparisonRequest(BaseModel):

    question: str = Field(
        ...,
        min_length=3,
        description="Question about company documents"
    )

    top_k: int = Field(
        default=4,
        ge=1,
        le=10
    )


@router.get("/health")
async def health_check():

    return {
        "status": "healthy",
        "message": "RAG Comparison API is running"
    }


@router.post("/compare")
async def compare(request: ComparisonRequest):

    try:

        result = await run_comparison(
            question=request.question,
            top_k=request.top_k
        )

        return result

    except Exception as error:

        raise HTTPException(
            status_code=500,
            detail=str(error)
        )