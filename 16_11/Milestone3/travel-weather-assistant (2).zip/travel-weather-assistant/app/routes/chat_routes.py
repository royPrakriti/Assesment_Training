
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional

from app.services.memory_service import (
    get_conversation_history,
    get_session_trip_id,
    save_exchange
)

from app.chains.travel_chain import generate_travel_advisory


router = APIRouter(
    prefix="/chat",
    tags=["Travel Assistant"]
)


class ChatRequest(BaseModel):
    session_id: str = Field(min_length=1)
    question: str = Field(min_length=1)
    trip_id: Optional[str] = None


@router.post("/")
def chat_with_assistant(request: ChatRequest):

    # Step 1: Identify the employee's trip
    trip_id = request.trip_id or get_session_trip_id(
        request.session_id
    )

    if not trip_id:
        raise HTTPException(
            status_code=400,
            detail="Please provide a trip_id to start the conversation."
        )

    # Step 2: Retrieve previous conversation
    history = get_conversation_history(
        request.session_id
    )

    # Step 3: Generate travel advisory
    result = generate_travel_advisory(
        trip_id=trip_id,
        question=request.question,
        conversation_history=history
    )

    if not result.get("success"):
        raise HTTPException(
            status_code=404,
            detail=result.get("message", "Unable to generate advisory.")
        )

    answer = result["advisory"]

    # Step 4: Save conversation in Redis
    save_exchange(
        session_id=request.session_id,
        question=request.question,
        answer=answer,
        trip_id=trip_id
    )

    # Step 5: Return response
    return {
        "success": True,
        "session_id": request.session_id,
        "trip_id": trip_id,
        "destination": result["trip"]["destination"],
        "answer": answer
    }
