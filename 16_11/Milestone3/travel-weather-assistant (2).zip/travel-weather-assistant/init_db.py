
from app.database.database import Base, engine
from app.database.models import Trip

Base.metadata.create_all(bind=engine)

print("Travel database initialized successfully!")
