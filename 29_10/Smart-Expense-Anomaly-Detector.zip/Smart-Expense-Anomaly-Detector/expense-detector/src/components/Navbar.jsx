
import { useNavigate } from "react-router-dom";
import { logoutUser } from "../services/authService";

function Navbar() {
  const navigate = useNavigate();

  async function handleLogout() {
    try {
      await logoutUser();
    } catch {
      // Clear local state even if the backend is unreachable.
    } finally {
      localStorage.removeItem("token");
      navigate("/login", { replace: true });
    }
  }

  return (
    <header className="navbar">
      <div>
        <p className="navbar-label">PERSONAL FINANCE</p>
        <h2>Smart Expense Anomaly Detector</h2>
      </div>

      <button
        type="button"
        className="logout-button"
        onClick={handleLogout}
      >
        Log out
      </button>
    </header>
  );
}

export default Navbar;
