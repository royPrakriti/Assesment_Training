
from pydantic import BaseModel, EmailStr, Field
from datetime import date
from pydantic import BaseModel, Field


class RegisterRequest(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr


class ExpenseCreate(BaseModel):
    amount: float = Field(gt=0)
    category_id: int = Field(gt=0)
    description: str = Field(min_length=1, max_length=255)
    expense_date: date