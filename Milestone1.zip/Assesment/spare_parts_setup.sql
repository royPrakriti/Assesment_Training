import psycopg2
import pylab as p

conn = psycopg2.connect(
    host="localhost",
    database = "spare_parts_assessment",
    user = "postgres",
    password = "Admin@123",
    port = "5432"
)

cur = conn.cursor()
1.
select * from parts where category = 'Mechanical';
2.
select * from parts where unit_price > 100
order by unit_price desc;

3.
select category, avg(unit_price) as  average_price
from parts
group by category;

4.
select category, sum(stock_quantity) as total_stock
from parts
group by category;

5.
select po.po_id, s.supplier_name, po.order_date, po.status
from purchase_orders po
join suppliers s
on po.supplier_id = s.supplier_id;

6.
select po.po_id, p.part_name, poi.quantity, p.unit_price
from purchase_orders po
join purchase_order_items  poi
on po.po_id = poi.po_id
join parts p on poi.part_id = p.part_id

7.
select po.po_id, p.part_name, poi.quantity, p.unit_price, poi.quantity * p.unit_price as line_total
from purchase_orders po
join purchase_order_items poi on
po.po_id = poi.po_id
join parts p on poi.part_id = p.part_id;

8.select * from suppliers s
left join purchase_orders po
on s.supplier_id = po.supplier_id;

9.
select * from suppliers s
left join purchase_orders po
on s.supplier_id = po.supplier_id;
where po.po_id is Null;

10.

create view purchase_order_summary as
select po.po_id, po.supplier_name, p.part_name, poi.quantity,p.unit_price,poi.quantity * p.unit_price as line_total,
po.status
from purchase_orders po
join suppliers s on po.supplier_id = s.supplier_id
join purchase_order_items poi on po.po_id = poi.po_id
join parts p on poi.part_id = p.part_id;

select * from purchase_order_summary
where status = 'Pending':

11.
Create or replace function
calculate_part_discount( amount numeric)
returns numeric
language plpgsql
as $$
begin
    if amount >= 2000 then
         return amount * 0.10
    else
        return 0;
    end if;

end;
$$;


select part_name, unit_price,
calculate_part_discount(unit_price) as discount
from parts;

create or replace function
final_part_price(amount numeric)
return numeric
language plpgsql
as $$
begin
     return amount - calculate_part_discount(amount);
end;
$$;

select part_name, unit_price, final_part_price(unit_price) as final_part_price from parts;