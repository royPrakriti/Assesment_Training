import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer
} from "recharts";

function ComparisonChart({ results }) {

    const data = Object.entries(results || {})
        .filter(([_, result]) =>
            result.status === "success" && result.answer
        )
        .map(([model, result]) => ({
            model: model.toUpperCase(),
            time: result.response_time
        }));

    return (
        <div className="chart-card">

            <h3>Response Time Comparison</h3>

            <p>Time taken by each model to generate an answer</p>

            <div className="chart-container">

                <ResponsiveContainer width="100%" height="100%">

                    <BarChart data={data}>

                        <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="#333"
                        />

                        <XAxis
                            dataKey="model"
                            stroke="#aaa"
                        />

                        <YAxis
                            stroke="#aaa"
                            unit="s"
                        />

                        <Tooltip
                            contentStyle={{
                                background: "#202020",
                                border: "1px solid #444",
                                borderRadius: "8px"
                            }}
                        />

                        <Bar
                            dataKey="time"
                            fill="#facc15"
                            radius={[6, 6, 0, 0]}
                        />

                    </BarChart>

                </ResponsiveContainer>

            </div>
        </div>
    );
}

export default ComparisonChart;