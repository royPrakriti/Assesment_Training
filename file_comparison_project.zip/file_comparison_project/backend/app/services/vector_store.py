import chromadb
from sentence_transformers import SentenceTransformer

from app.core.config import (
    EMBEDDING_MODEL,
    CHROMA_DB_PATH,
    COLLECTION_NAME,
    TOP_K
)

from app.services.document_processor import process_documents


# Initialize embedding model
embedding_model = SentenceTransformer(EMBEDDING_MODEL)

# Initialize ChromaDB
client = chromadb.PersistentClient(path=CHROMA_DB_PATH)

collection = client.get_or_create_collection(
    name=COLLECTION_NAME,
    metadata={"hnsw:space": "cosine"}
)


def create_vector_store():

    chunks = process_documents("data")

    if not chunks:
        raise ValueError("No documents found in the data folder.")

    ids = []
    texts = []
    metadatas = []

    for chunk in chunks:

        chunk_id = f"{chunk['source']}_{chunk['chunk_id']}"

        ids.append(chunk_id)
        texts.append(chunk["text"])

        metadatas.append({
            "source": chunk["source"],
            "chunk_id": chunk["chunk_id"]
        })

    # Generate embeddings
    embeddings = embedding_model.encode(
        texts,
        convert_to_numpy=True
    ).tolist()

    # Insert or update documents
    collection.upsert(
        ids=ids,
        documents=texts,
        embeddings=embeddings,
        metadatas=metadatas
    )

    return {
        "message": "Documents successfully indexed",
        "total_chunks": len(chunks)
    }


def retrieve_context(question, top_k=TOP_K):

    # Generate query embedding
    query_embedding = embedding_model.encode(
        question,
        convert_to_numpy=True
    ).tolist()

    # Search ChromaDB
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=min(top_k, collection.count())
    )

    retrieved_chunks = []

    for index in range(len(results["documents"][0])):

        retrieved_chunks.append({
            "text": results["documents"][0][index],
            "source": results["metadatas"][0][index]["source"],
            "chunk_id": results["metadatas"][0][index]["chunk_id"],
            "distance": results["distances"][0][index]
        })

    return retrieved_chunks