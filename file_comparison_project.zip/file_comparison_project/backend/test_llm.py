import asyncio

from app.services.llm_service import compare_models


async def main():

    question = "How many annual leave days do employees receive?"

    context = """
    Full-time employees receive 16 days
    of paid annual leave each calendar year.
    """

    results = await compare_models(question, context)

    for model, result in results.items():

        print("\n" + "=" * 40)
        print("MODEL:", model)
        print("STATUS:", result["status"])

        if result["status"] == "success":
            print("ANSWER:", result["answer"])
            print("TIME:", result["response_time"])
            print("INPUT TOKENS:", result["input_tokens"])
            print("OUTPUT TOKENS:", result["output_tokens"])

        else:
            print("ERROR:", result["error"])


asyncio.run(main())