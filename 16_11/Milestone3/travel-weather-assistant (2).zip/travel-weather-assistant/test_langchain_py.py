
from app.tools.trip_tool import get_saved_trip
from app.tools.weather_tool import weather_lookup

trip_id = "e4e73a94-c54a-4a65-94d0-fed5d9792c8d"

print("\n--- TRIP TOOL ---")

trip = get_saved_trip.invoke({
    "trip_id": trip_id
})

print(trip)


print("\n--- WEATHER TOOL ---")

weather = weather_lookup.invoke({
    "city": "Jaipur",
    "start_date": "2026-11-20",
    "end_date": "2026-11-23"
})

print(weather)
