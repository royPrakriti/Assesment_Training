
import api from "./api";

export async function getDashboardSummary(filters = {}) {
  const response = await api.get("/dashboard/summary", {
    params: filters,
  });
  return response.data;
}

