
import { useEffect, useState } from "react";
import { addExpense, getCategories } from "../services/expenseService";

function AddExpense() {
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({
    amount: "",
    category_id: "",
    description: "",
    expense_date: new Date().toISOString().slice(0, 10),
  });

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadCategories() {
      try {
        const data = await getCategories();
        setCategories(Array.isArray(data) ? data : data.categories ?? []);
      } catch {
        setError("Unable to load categories. Check your backend connection.");
      }
    }

    loadCategories();
  }, []);

  function handleChange(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setMessage("");
    setError("");
    setLoading(true);

    try {
      const result = await addExpense({
        amount: Number(form.amount),
        category_id: Number(form.category_id),
        description: form.description,
        expense_date: form.expense_date,
      });

      setMessage(
        result.is_flagged
          ? `Expense added. Anomaly detected: ${(result.anomaly_reasons ?? []).join(", ")}`
          : "Expense added successfully. No anomaly was reported."
      );

      setForm({
        amount: "",
        category_id: "",
        description: "",
        expense_date: new Date().toISOString().slice(0, 10),
      });
    } catch (err) {
      setError(
        err.response?.data?.detail ??
          "Unable to add expense. Check your input and backend."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <section>
      <div className="page-heading">
        <div>
          <h1>Add Expense</h1>
          <p>Record a transaction and check for unusual spending.</p>
        </div>
      </div>

      <div className="content-card form-card">
        <form onSubmit={handleSubmit}>
          <label htmlFor="amount">Amount (₹)</label>
          <input
            id="amount"
            name="amount"
            type="number"
            min="0.01"
            step="0.01"
            value={form.amount}
            onChange={handleChange}
            placeholder="Enter amount"
            required
          />

          <label htmlFor="category_id">Category</label>
          <select
            id="category_id"
            name="category_id"
            value={form.category_id}
            onChange={handleChange}
            required
          >
            <option value="">Select a category</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>

          <label htmlFor="description">Description</label>
          <input
            id="description"
            name="description"
            value={form.description}
            onChange={handleChange}
            placeholder="e.g. Lunch, groceries or travel"
            required
          />

          <label htmlFor="expense_date">Expense Date</label>
          <input
            id="expense_date"
            name="expense_date"
            type="date"
            value={form.expense_date}
            onChange={handleChange}
            required
          />

          {message && <p className="success-message">{message}</p>}
          {error && <p className="error-message">{error}</p>}

          <button type="submit" disabled={loading}>
            {loading ? "Saving..." : "Save Expense"}
          </button>
        </form>
      </div>
    </section>
  );
}

export default AddExpense;
