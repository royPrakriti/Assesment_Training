from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router
from app.services.vector_store import create_vector_store

app = FastAPI(
    title="Multi-LLM RAG Comparison",
    description="Compare three LLMs using the same retrieved document context.",
    version="1.0.0"
)


# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


@app.on_event("startup")
async def startup_event():

    create_vector_store()


app.include_router(
    router,
    prefix="/api",
    tags=["RAG Comparison"]
)


@app.get("/")
async def root():

    return {
        "message": "Multi-LLM RAG Comparison Backend"
    }