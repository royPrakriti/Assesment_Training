import os
from app.database.database import engine

print(os.path.abspath(engine.url.database))