import { BrainCircuit, Activity, CircleCheck } from "lucide-react";

function Navbar({ connected }) {
    return (
        <nav className="navbar">
            <div className="nav-brand">
                <div className="brand-icon">
                    <BrainCircuit size={25} />
                </div>

                <div>
                    <h2>MODEL ARENA</h2>
                    <span>Multi-LLM RAG Benchmark</span>
                </div>
            </div>

            <div className="nav-status">
                <Activity size={17} />

                <span>
                    {connected ? "Backend Connected" : "Backend Offline"}
                </span>

                <CircleCheck
                    size={17}
                    color={connected ? "#22c55e" : "#ef4444"}
                />
            </div>
        </nav>
    );
}

export default Navbar;