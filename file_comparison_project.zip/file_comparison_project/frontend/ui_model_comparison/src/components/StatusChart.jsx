import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    ResponsiveContainer
} from "recharts";

function StatusChart({ results }) {

    const values = Object.values(results || {});

    const successful = values.filter(
        r => r.status === "success" && r.answer
    ).length;

    const failed = values.length - successful;

    const data = [
        { name: "Successful", value: successful },
        { name: "Failed", value: failed }
    ];

    const COLORS = ["#22c55e", "#ef4444"];

    return (
        <div className="chart-card">

            <h3>Model Response Distribution</h3>

            <p>Successful and failed API responses</p>

            <div className="chart-container">

                <ResponsiveContainer width="100%" height="100%">

                    <PieChart>

                        <Pie
                            data={data}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={85}
                            label
                        >
                            {data.map((entry, index) => (
                                <Cell
                                    key={entry.name}
                                    fill={COLORS[index]}
                                />
                            ))}
                        </Pie>

                        <Tooltip />

                    </PieChart>

                </ResponsiveContainer>

            </div>
        </div>
    );
}

export default StatusChart;