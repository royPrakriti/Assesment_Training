
import { useEffect, useState } from "react";
import { getDashboardSummary } from "../services/dashboardService";

function Dashboard() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDashboard() {
      try {
        const data = await getDashboardSummary();
        setSummary(data);
      } catch (err) {
        setError("Unable to load dashboard. Check your backend connection.");
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  if (loading) return <p>Loading dashboard...</p>;

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  const total = Number(summary?.total_spending ?? 0);
  const expenseCount = summary?.expense_count ?? 0;
  const flaggedCount = summary?.flagged_count ?? 0;

  return (
    <section>
      <div className="page-heading">
        <div>
          <h1>Dashboard</h1>
          <p>Get an overview of your spending and unusual expenses.</p>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <p>Total Spending</p>
          <h2>₹{total.toLocaleString("en-IN")}</h2>
        </div>

        <div className="stat-card">
          <p>Total Transactions</p>
          <h2>{expenseCount}</h2>
        </div>

        <div className="stat-card">
          <p>Flagged Expenses</p>
          <h2>{flaggedCount}</h2>
        </div>
      </div>

      <div className="content-card">
        <h2>Spending by Category</h2>

        {summary?.category_totals?.length ? (
          summary.category_totals.map((item, index) => (
            <div className="category-row" key={item.category_id ?? item.category_name ?? index}>
              <span>{item.category_name ?? item.category ?? "Other"}</span>
              <strong>
                ₹{Number(item.total ?? item.amount ?? 0).toLocaleString("en-IN")}
              </strong>
            </div>
          ))
        ) : (
          <p>No category spending available yet.</p>
        )}
      </div>
    </section>
  );
}

export default Dashboard;
