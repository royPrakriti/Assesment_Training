
import requests
from datetime import date
from langchain.tools import tool

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"


def get_coordinates(city: str):
    """Convert a city name into geographical coordinates."""

    try:
        response = requests.get(
            GEOCODING_URL,
            params={
                "name": city,
                "count": 5,
                "language": "en",
                "format": "json"
            },
            timeout=15
        )

        response.raise_for_status()
        data = response.json()

        results = data.get("results", [])

        if not results:
            return {
                "success": False,
                "message": f"No location found for {city}"
            }

        location = results[0]

        return {
            "success": True,
            "city": location["name"],
            "country": location.get("country", "Unknown"),
            "latitude": location["latitude"],
            "longitude": location["longitude"]
        }

    except requests.RequestException as e:
        return {
            "success": False,
            "message": f"Geocoding service error: {str(e)}"
        }


def get_weather_forecast(
    city: str,
    start_date: str,
    end_date: str
):
    """Retrieve daily weather information for a city and trip."""

    try:
        start = date.fromisoformat(start_date)
        end = date.fromisoformat(end_date)

        if end < start:
            return {
                "success": False,
                "message": "End date cannot be before start date."
            }

        if start < date.today():
            return {
                "success": False,
                "message": "Past dates cannot be forecast."
            }

        location = get_coordinates(city)

        if not location["success"]:
            return location

        response = requests.get(
            FORECAST_URL,
            params={
                "latitude": location["latitude"],
                "longitude": location["longitude"],
                "daily": (
                    "temperature_2m_max,"
                    "temperature_2m_min,"
                    "precipitation_probability_max,"
                    "precipitation_sum,"
                    "weather_code"
                ),
                "timezone": "auto",
                "forecast_days": 16
            },
            timeout=20
        )

        response.raise_for_status()
        data = response.json()

        daily = data.get("daily", {})
        forecast_dates = daily.get("time", [])

        if not forecast_dates:
            return {
                "success": False,
                "message": "Weather forecast data is unavailable."
            }

        weather_codes = {
            0: "Clear sky",
            1: "Mainly clear",
            2: "Partly cloudy",
            3: "Overcast",
            45: "Fog",
            48: "Depositing rime fog",
            51: "Light drizzle",
            53: "Moderate drizzle",
            55: "Dense drizzle",
            61: "Slight rain",
            63: "Moderate rain",
            65: "Heavy rain",
            71: "Slight snowfall",
            73: "Moderate snowfall",
            75: "Heavy snowfall",
            80: "Rain showers",
            81: "Moderate rain showers",
            82: "Violent rain showers",
            95: "Thunderstorm"
        }

        forecasts = []

        for index, forecast_date in enumerate(forecast_dates):

            if start_date <= forecast_date <= end_date:

                code = daily["weather_code"][index]

                forecasts.append({
                    "date": forecast_date,
                    "temperature_max": daily["temperature_2m_max"][index],
                    "temperature_min": daily["temperature_2m_min"][index],
                    "precipitation_probability": (
                        daily["precipitation_probability_max"][index]
                    ),
                    "precipitation_sum": daily["precipitation_sum"][index],
                    "condition": weather_codes.get(
                        code, f"Weather code {code}"
                    )
                })

        expected_dates = (end - start).days + 1

        if len(forecasts) != expected_dates:
            return {
                "success": False,
                "message": (
                    "The complete trip forecast is unavailable. "
                    "Some requested dates are outside the provider's "
                    "available forecast data."
                ),
                "available_dates": [
                    item["date"] for item in forecasts
                ]
            }

        return {
            "success": True,
            "location": location["city"],
            "country": location["country"],
            "start_date": start_date,
            "end_date": end_date,
            "forecasts": forecasts
        }

    except ValueError:
        return {
            "success": False,
            "message": "Invalid date format. Use YYYY-MM-DD."
        }

    except (requests.RequestException, KeyError, TypeError) as e:
        return {
            "success": False,
            "message": f"Weather service error: {str(e)}"
        }


@tool
def weather_lookup(
    city: str,
    start_date: str,
    end_date: str
) -> dict:
    """
    Retrieve actual weather forecasts for a city
    between the specified travel dates.
    """

    return get_weather_forecast(
        city=city,
        start_date=start_date,
        end_date=end_date
    )
