from app.services.vector_store import retrieve_context
from app.services.llm_service import compare_models


async def run_comparison(question, top_k=4):

    # Step 1: Retrieve relevant chunks
    retrieved_chunks = retrieve_context(
        question,
        top_k=top_k
    )

    if not retrieved_chunks:
        raise ValueError("No relevant documents found.")

    # Step 2: Prepare shared context
    context = "\n\n".join(
        chunk["text"] for chunk in retrieved_chunks
    )

    # Step 3: Generate responses from all models
    model_results = await compare_models(
        question,
        context
    )

    # Step 4: Identify fastest successful model
    successful_results = [
        result
        for result in model_results.values()
        if result["status"] == "success"
        and result.get("answer")
    ]

    fastest_model = None

    if successful_results:
        fastest_model = min(
            successful_results,
            key=lambda result: result["response_time"]
        )

    # Step 5: Prepare source information
    sources = list({
        chunk["source"]
        for chunk in retrieved_chunks
    })

    # Step 6: Return comparison
    return {
        "question": question,

        "models": model_results,

        "fastest_model": (
            fastest_model["model"]
            if fastest_model else None
        ),

        "fastest_response_time": (
            fastest_model["response_time"]
            if fastest_model else None
        ),

        "successful_models": len(successful_results),

        "total_models": len(model_results),

        "sources": sources
    }