import time
import asyncio
from openai import AsyncOpenAI

from app.core.config import (
    OPENROUTER_API_KEY,
    OPENROUTER_BASE_URL,
    MODELS,
    MAX_TOKENS,
    TEMPERATURE
)


# OpenRouter API client
client = AsyncOpenAI(
    api_key=OPENROUTER_API_KEY,
    base_url=OPENROUTER_BASE_URL,
    timeout=120.0
)


async def generate_response(model_name, question, context):

    start_time = time.perf_counter()

    prompt = f"""
You are a helpful company policy assistant.

Instructions:
1. Answer using only the provided context.
2. Do not make up information.
3. If the answer is unavailable, clearly state that.
4. Keep the answer clear and concise.

Context:
{context}

Question:
{question}

Answer:
"""

    try:

        response = await client.chat.completions.create(
            model=MODELS[model_name],
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=TEMPERATURE,
            max_tokens=MAX_TOKENS
        )

        end_time = time.perf_counter()

        answer = response.choices[0].message.content

        usage = response.usage

        return {
            "model": model_name,
            "model_id": MODELS[model_name],
            "answer": answer,
            "response_time": round(end_time - start_time, 3),
            "input_tokens": usage.prompt_tokens if usage else None,
            "output_tokens": usage.completion_tokens if usage else None,
            "status": "success"
        }

    except Exception as error:

        end_time = time.perf_counter()

        return {
            "model": model_name,
            "model_id": MODELS[model_name],
            "answer": None,
            "response_time": round(end_time - start_time, 3),
            "error": str(error),
            "status": "failed"
        }


async def compare_models(question, context):

    tasks = [
    generate_response("llama", question, context),
    generate_response("nemotron", question, context),
    generate_response("dots", question, context)
    ]
    results = await asyncio.gather(*tasks)

    return {
    model["model"]: model
    for model in results
    }