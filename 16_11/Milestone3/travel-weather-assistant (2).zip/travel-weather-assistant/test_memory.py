
from app.services.memory_service import (
    save_exchange,
    get_session_data,
    get_conversation_history,
    get_session_trip_id
)

session_id = "EMP104_SESSION"

trip_id = "e4e73a94-c54a-4a65-94d0-fed5d9792c8d"

# First conversation
save_exchange(
    session_id=session_id,
    question="What is the weather in Jaipur?",
    answer="The forecast shows clear skies.",
    trip_id=trip_id
)

# Follow-up conversation
save_exchange(
    session_id=session_id,
    question="Will I need an umbrella?",
    answer="The forecast shows low precipitation probability, so an umbrella is unlikely to be necessary."
)

print("\n--- SESSION DATA ---")
print(get_session_data(session_id))

print("\n--- CONVERSATION HISTORY ---")
print(get_conversation_history(session_id))

print("\n--- REMEMBERED TRIP ID ---")
print(get_session_trip_id(session_id))
