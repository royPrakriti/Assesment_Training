import {
    Clock,
    Coins,
    Zap,
    CheckCircle,
    XCircle
} from "lucide-react";

function ModelCard({ model, result, fastest }) {

    const modelNames = {
        llama: "Llama 3.2",
        nemotron: "Nemotron 3.5 Lightning",
        dots: "Dots3-Note Preview"
    };

    const isSuccess =
        result?.status === "success" && result?.answer;

    return (
        <div className={`model-card ${fastest ? "fastest-card" : ""}`}>

            <div className="model-header">

                <div>
                    <h3>{modelNames[model] || model}</h3>
                    <span>AI Language Model</span>
                </div>

                {isSuccess ? (
                    <CheckCircle color="#22c55e" />
                ) : (
                    <XCircle color="#ef4444" />
                )}

            </div>

            <div className="model-answer">
                {isSuccess
                    ? result.answer
                    : result?.error || "No response available."
                }
            </div>

            <div className="model-metrics">

                <div>
                    <Clock size={16} />
                    <span>
                        {result?.response_time ?? "--"} sec
                    </span>
                </div>

                <div>
                    <Zap size={16} />
                    <span>
                        {result?.input_tokens ?? "--"} input
                    </span>
                </div>

                <div>
                    <Coins size={16} />
                    <span>
                        {result?.output_tokens ?? "--"} output
                    </span>
                </div>

            </div>

            {fastest && isSuccess && (
                <div className="fastest-label">
                    <Zap size={14} />
                    Fastest Response
                </div>
            )}

        </div>
    );
}

export default ModelCard;