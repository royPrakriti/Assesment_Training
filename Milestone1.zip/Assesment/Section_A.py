import json
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('urban_mobility.csv')
1.
print(df.head(5))
2.
df["Energy_Per_Km"] = df["Energy_Used_kWh"]/df["Distance_Km"]
3.
print(df[(df["Vehicle_Type"] == "Electric Van") & (df["Maintenance_Flag"] == "Yes")])
4.
print(df.groupby("Vehicle_Type").agg({"Distance_Km": "mean","Trips_Count":"sum"}))
5.
a = df["Energy_Used_kWh"].to_numpy()
print("Mean:",np.mean(a),"\nMax:" ,np.max(a),"\nMin",np.min(a))

6.
df.groupby("Vehicle_Type")["Energy_Used_kWh"].mean().plot(kind="bar")
plt.xlabel("Vehicle Type")
plt.ylabel("Energy Used kWh")
plt.show()

7.
with open("equipment_events.json") as file:
    data = json.load(file)
for e in data:
    print(e["event_id"],e["asset"]["type"],e["asset"]["site"],e["severity"])
8.
for e in data:
    if e["temperature"] > 70:
        print(e)
for  e in data:
    print(e.get("actions") or "No actions recorded")

9.
with open("coastal_monitoring_log.txt") as file:
    datas = file.read()

count = 0
count_for_inspection = 0
for data in datas.split():
    count += 1
    if data.lower() == "inspection":
        count_for_inspection += 1


print(f"count for total words: {count}")
print(f"Count for inspection: {count_for_inspection}")


10.

for data in datas.split("\n"):
    if "boardwalk" in data or "maintenance" in data or "wind" in data:
        print(data)




