import os
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_BASE_URL = os.getenv(
    "OPENROUTER_BASE_URL",
    "https://openrouter.ai/api/v1"
)

MODELS = {
    "llama": "meta-llama/llama-3.2-3b-instruct",

    "nemotron": "nvidia/nemotron-3.5-lightning:free",

    "dots": "dots-studio/dots-3-note-preview:free"
}

EMBEDDING_MODEL = "all-MiniLM-L6-v2"

CHROMA_DB_PATH = "./chroma_db"
COLLECTION_NAME = "company_documents"

CHUNK_SIZE = 120
CHUNK_OVERLAP = 20
TOP_K = 4

MAX_TOKENS = 1000
TEMPERATURE = 0.2