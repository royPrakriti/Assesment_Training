
from fastapi import FastAPI

from app.routes.trip_routes import router as trip_router
from app.routes.chat_routes import router as chat_router

from app.database.database import Base, engine

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-Powered Travel & Weather Advisory Assistant",
    description="Business travel assistant with weather intelligence and Redis conversation memory",
    version="1.0.0"
)

app.include_router(trip_router)
app.include_router(chat_router)


@app.get("/")
def home():
    return {
        "message": "Travel Weather Assistant API is running!"
    }
