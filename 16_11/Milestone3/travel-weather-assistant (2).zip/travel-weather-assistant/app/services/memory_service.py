
import json
import redis

# Connect to Redis running inside Docker
redis_client = redis.Redis(
    host="127.0.0.1",
    port=6379,
    decode_responses=True
)

SESSION_TTL = 86400  # 24 hours
MAX_HISTORY = 10


def get_session_data(session_id: str):
    """
    Retrieve conversation data for a session.
    """

    key = f"travel:session:{session_id}"

    data = redis_client.get(key)

    if data:
        return json.loads(data)

    return {
        "trip_id": None,
        "history": []
    }


def save_exchange(
    session_id: str,
    question: str,
    answer: str,
    trip_id: str = None
):
    """
    Save one question-answer exchange in Redis.
    """

    key = f"travel:session:{session_id}"

    session = get_session_data(session_id)

    if trip_id:
        session["trip_id"] = trip_id

    session["history"].append({
        "question": question,
        "answer": answer
    })

    # Retain only the most recent 10 exchanges
    session["history"] = session["history"][-MAX_HISTORY:]

    redis_client.setex(
        key,
        SESSION_TTL,
        json.dumps(session)
    )

    return session


def get_conversation_history(session_id: str):
    """
    Return formatted conversation history.
    """

    session = get_session_data(session_id)

    formatted_history = []

    for exchange in session["history"]:
        formatted_history.append(
            f"Employee: {exchange['question']}"
        )

        formatted_history.append(
            f"Assistant: {exchange['answer']}"
        )

    return "\n".join(formatted_history)


def get_session_trip_id(session_id: str):
    """
    Retrieve the trip ID associated with a session.
    """

    session = get_session_data(session_id)

    return session.get("trip_id")
