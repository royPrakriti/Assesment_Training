
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field, model_validator
from datetime import date

from app.database.database import get_db
from app.database.models import Trip

router = APIRouter(prefix="/trips", tags=["Trips"])


class TripCreate(BaseModel):
    employee_id: str
    destination: str
    start_date: date
    end_date: date
    purpose: str

    @model_validator(mode="after")
    def validate_dates(self):
        if self.end_date < self.start_date:
            raise ValueError("End date cannot be before start date")

        if self.start_date < date.today():
            raise ValueError("Trip start date cannot be in the past")

        return self


@router.post("/")
def create_trip(
    trip_data: TripCreate,
    db: Session = Depends(get_db)
):
    trip = Trip(
        employee_id=trip_data.employee_id,
        destination=trip_data.destination,
        start_date=trip_data.start_date,
        end_date=trip_data.end_date,
        purpose=trip_data.purpose
    )

    db.add(trip)
    db.commit()
    db.refresh(trip)

    return {
        "message": "Trip registered successfully",
        "trip_id": trip.trip_id,
        "employee_id": trip.employee_id,
        "destination": trip.destination,
        "start_date": trip.start_date,
        "end_date": trip.end_date,
        "purpose": trip.purpose,
        "status": trip.status
    }


@router.get("/{trip_id}")
def get_trip(
    trip_id: str,
    db: Session = Depends(get_db)
):
    trip = db.query(Trip).filter(
        Trip.trip_id == trip_id
    ).first()

    if not trip:
        raise HTTPException(
            status_code=404,
            detail="Trip not found"
        )

    return {
        "trip_id": trip.trip_id,
        "employee_id": trip.employee_id,
        "destination": trip.destination,
        "start_date": trip.start_date,
        "end_date": trip.end_date,
        "purpose": trip.purpose,
        "status": trip.status
    }
