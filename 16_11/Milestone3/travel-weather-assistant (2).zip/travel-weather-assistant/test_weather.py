
from app.tools.weather_tool import (
    get_coordinates,
    get_weather_forecast
)

print("\n--- LOCATION TEST ---")

location = get_coordinates("Jaipur")
print(location)


print("\n--- WEATHER FORECAST TEST ---")

weather = get_weather_forecast(
    city="Jaipur",
    start_date="2026-11-20",
    end_date="2026-11-23"
)

print(weather)
