
from app.tools.trip_tool import get_saved_trip

trip_id = "e4e73a94-c54a-4a65-94d0-fed5d9792c8d"

result = get_saved_trip(trip_id)

print(result)
