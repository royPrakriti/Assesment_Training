import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer
} from "recharts";

function TokenChart({ results }) {

    const data = Object.entries(results || {})
        .filter(([_, result]) => result.status === "success")
        .map(([model, result]) => ({
            model: model.toUpperCase(),
            input: result.input_tokens || 0,
            output: result.output_tokens || 0
        }));

    return (
        <div className="chart-card">

            <h3>Token Consumption</h3>

            <p>Input and output tokens across models</p>

            <div className="chart-container">

                <ResponsiveContainer width="100%" height="100%">

                    <BarChart data={data}>

                        <CartesianGrid
                            strokeDasharray="3 3"
                            stroke="#333"
                        />

                        <XAxis dataKey="model" stroke="#aaa" />

                        <YAxis stroke="#aaa" />

                        <Tooltip />

                        <Legend />

                        <Bar
                            dataKey="input"
                            name="Input Tokens"
                            fill="#facc15"
                        />

                        <Bar
                            dataKey="output"
                            name="Output Tokens"
                            fill="#38bdf8"
                        />

                    </BarChart>

                </ResponsiveContainer>

            </div>
        </div>
    );
}

export default TokenChart;