from app.database.database import engine, SessionLocal
from app.database.models import Trip

print("DATABASE PATH:", engine.url.database)

db = SessionLocal()

try:
    trips = db.query(Trip).all()

    print("TOTAL TRIPS:", len(trips))

    for trip in trips:
        print(
            trip.trip_id,
            trip.employee_id,
            trip.destination,
            trip.start_date,
            trip.end_date,
            trip.purpose,
            trip.status
        )

finally:
    db.close()
