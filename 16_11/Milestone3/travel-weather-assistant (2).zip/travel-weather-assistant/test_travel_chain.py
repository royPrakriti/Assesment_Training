
from app.chains.travel_chain import generate_travel_advisory

trip_id = "e4e73a94-c54a-4a65-94d0-fed5d9792c8d"

result = generate_travel_advisory(
    trip_id=trip_id,
    question="What will the weather be like, and what should I pack?"
)

print("\n--- TRAVEL ADVISORY ---")
print(result)
