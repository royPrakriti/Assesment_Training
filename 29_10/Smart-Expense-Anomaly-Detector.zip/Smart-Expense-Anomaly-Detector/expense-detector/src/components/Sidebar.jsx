
import { NavLink } from "react-router-dom";

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-logo">₹</div>
        <div>
          <h2>SpendWise</h2>
          <p>Expense intelligence</p>
        </div>
      </div>

      <p className="nav-heading">WORKSPACE</p>

      <NavLink to="/dashboard" className="nav-link">
        Dashboard
      </NavLink>

      <NavLink to="/add-expense" className="nav-link">
        Add Expense
      </NavLink>

      <NavLink to="/transactions" className="nav-link">
        Transactions
      </NavLink>

      <div className="sidebar-note">
        <strong>Smart detection</strong>
        <p>Understand unusual spending with clear explanations.</p>
      </div>
    </aside>
  );
}

export default Sidebar;
