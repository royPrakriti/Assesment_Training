
import json

from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from app.tools.trip_tool import get_saved_trip
from app.tools.weather_tool import weather_lookup


llm = ChatOllama(
    model="qwen2.5:3b",
    base_url="http://localhost:11434",
    temperature=0.2
)

prompt = ChatPromptTemplate.from_template("""
You are an AI-powered business travel and weather assistant.

Use ONLY the saved trip and weather information provided.
Never invent weather conditions, temperatures, or precipitation values.

PREVIOUS CONVERSATION:
{conversation_history}

SAVED TRIP:
{trip_data}

WEATHER FORECAST:
{weather_data}

CURRENT EMPLOYEE QUESTION:
{question}

Instructions:
1. Answer the employee's current question directly.
2. Use previous conversation to understand follow-up questions.
3. Include destination and travel dates when relevant.
4. Explain temperature and precipitation accurately.
5. Provide 3-4 practical travel or packing recommendations when appropriate.
6. Never claim precipitation probability is zero unless the data explicitly says zero.
7. If information is unavailable, clearly state that.

Keep your response concise and professional.
""")

advisory_chain = prompt | llm | StrOutputParser()


def generate_travel_advisory(
    trip_id: str,
    question: str,
    conversation_history: str = ""
):

    # Stage 1: Retrieve saved trip
    trip = get_saved_trip.invoke({
        "trip_id": trip_id
    })

    if not trip.get("success"):
        return {
            "success": False,
            "message": trip.get("message", "Trip not found.")
        }

    # Stage 2: Retrieve actual weather forecast
    weather = weather_lookup.invoke({
        "city": trip["destination"],
        "start_date": trip["start_date"],
        "end_date": trip["end_date"]
    })

    if not weather.get("success"):
        return {
            "success": False,
            "message": weather.get("message", "Weather unavailable."),
            "trip": trip
        }

    # Stage 3: Generate response using conversation context
    response = advisory_chain.invoke({
        "trip_data": json.dumps(trip, indent=2),
        "weather_data": json.dumps(weather, indent=2),
        "question": question,
        "conversation_history": conversation_history or "No previous conversation."
    })

    return {
        "success": True,
        "trip": trip,
        "weather": weather,
        "advisory": response
    }
