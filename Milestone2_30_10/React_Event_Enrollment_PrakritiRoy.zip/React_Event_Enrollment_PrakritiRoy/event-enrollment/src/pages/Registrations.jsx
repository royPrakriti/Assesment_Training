import { useEvents } from "../context/EventContext";
import events from "../data/events";
 
function Registrations() {
 
  const { registrations, cancelRegistration } = useEvents();
 
  const handleCancel = (id) => {
    const confirmCancel = window.confirm(
      "Are you sure you want to cancel this registration?"
    );
 
    if (confirmCancel) {
      cancelRegistration(id);
      alert("Registration cancelled successfully!");
    }
  };
 
  return (
    <div className="registrations-page">
 
      <h2>Registered Attendees</h2>
 
      <p>Manage all event registrations here.</p>
 
      {registrations.length === 0 ? (
 
        <p>No registrations found.</p>
 
      ) : (
 
        <div className="registrations-container">
 
          {registrations.map((registration) => {
 
            const event = events.find(
              (e) => e.id === registration.eventId
            );
 
            return (
 
              <div className="registration-card" key={registration.id}>
 
                <h3>{registration.name}</h3>
 
                <p>Email: {registration.email}</p>
 
                <p>
                  Event: {event ? event.title : "Unknown Event"}
                </p>
 
                <p>Event ID: {registration.eventId}</p>
 
                <p>
                  Registered On:{" "}
                  {new Date(
                    registration.registrationDate
                  ).toLocaleDateString()}
                </p>
 
                <button
                  onClick={() => handleCancel(registration.id)}
                >
                  Cancel Registration
                </button>
 
              </div>
 
            );
 
          })}
 
        </div>
 
      )}
 
    </div>
  );
}
 
export default Registrations;