
from sqlalchemy import Column, String, Date, ForeignKey
from app.database.database import Base
import uuid


class Trip(Base):

    __tablename__ = "trips"

    trip_id = Column(
        String,
        primary_key=True,
        default=lambda: str(uuid.uuid4())
    )

    employee_id = Column(String, nullable=False, index=True)

    destination = Column(String, nullable=False)

    start_date = Column(Date, nullable=False)

    end_date = Column(Date, nullable=False)

    purpose = Column(String, nullable=False)

    status = Column(String, default="Planned")
