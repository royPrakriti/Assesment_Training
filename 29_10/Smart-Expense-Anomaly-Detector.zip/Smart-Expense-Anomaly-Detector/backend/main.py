
import json
from datetime import timedelta

from dotenv import load_dotenv
from fastapi import (
    FastAPI,
    Depends,
    HTTPException,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import text, func
from sqlalchemy.orm import Session

import models
from database import Base, engine, get_db
from schemas import (
    RegisterRequest,
    LoginRequest,
    TokenResponse,
    UserResponse,
    ExpenseCreate,
)
from security import (
    hash_password,
    verify_password,
    create_access_token,
    decode_access_token,
)

load_dotenv()

app = FastAPI(
    title="Smart Expense Anomaly Detector API",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

bearer_scheme = HTTPBearer()


# ---------------- HOME AND HEALTH ----------------

@app.get("/")
def home():
    return {
        "message": "Smart Expense Anomaly Detector API is running"
    }


@app.get("/api/v1/health")
def health_check():
    return {"status": "healthy"}


@app.get("/api/v1/db-check")
def database_check(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))

    return {
        "status": "connected",
        "database": "expense_detector",
    }


# ---------------- AUTHENTICATION ----------------

@app.post(
    "/api/v1/auth/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
)
def register_user(
    user_data: RegisterRequest,
    db: Session = Depends(get_db),
):
    email = str(user_data.email).lower().strip()

    existing_user = (
        db.query(models.User)
        .filter(models.User.email == email)
        .first()
    )

    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An account with this email already exists",
        )

    user = models.User(
        name=user_data.name.strip(),
        email=email,
        hashed_password=hash_password(user_data.password),
    )

    db.add(user)
    db.commit()
    db.refresh(user)

    return user


@app.post(
    "/api/v1/auth/login",
    response_model=TokenResponse,
)
def login_user(
    credentials: LoginRequest,
    db: Session = Depends(get_db),
):
    email = str(credentials.email).lower().strip()

    user = (
        db.query(models.User)
        .filter(models.User.email == email)
        .first()
    )

    if not user or not verify_password(
        credentials.password,
        user.hashed_password,
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
        )

    return {
        "access_token": create_access_token(user.id),
        "token_type": "bearer",
    }


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(
        bearer_scheme
    ),
    db: Session = Depends(get_db),
):
    try:
        payload = decode_access_token(credentials.credentials)
        user_id = int(payload["sub"])
    except (Exception,):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = (
        db.query(models.User)
        .filter(models.User.id == user_id)
        .first()
    )

    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
        )

    return user


@app.get(
    "/api/v1/auth/me",
    response_model=UserResponse,
)
def current_user(user=Depends(get_current_user)):
    return user


@app.post("/api/v1/auth/logout")
def logout_user(user=Depends(get_current_user)):
    # The frontend removes the JWT from localStorage.
    # This endpoint does not revoke the JWT server-side.
    return {"message": "Logged out successfully"}


# ---------------- DASHBOARD ----------------

@app.get("/api/v1/dashboard/summary")
def dashboard_summary(
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    total_spending = (
        db.query(
            func.coalesce(func.sum(models.Expense.amount), 0)
        )
        .filter(models.Expense.user_id == user.id)
        .scalar()
    )

    expense_count = (
        db.query(models.Expense)
        .filter(models.Expense.user_id == user.id)
        .count()
    )

    flagged_count = (
        db.query(models.Expense)
        .filter(
            models.Expense.user_id == user.id,
            models.Expense.is_flagged.is_(True),
        )
        .count()
    )

    category_totals = (
        db.query(
            models.Category.id.label("category_id"),
            models.Category.name.label("category_name"),
            func.sum(models.Expense.amount).label("total"),
        )
        .join(
            models.Expense,
            models.Expense.category_id == models.Category.id,
        )
        .filter(models.Expense.user_id == user.id)
        .group_by(
            models.Category.id,
            models.Category.name,
        )
        .order_by(func.sum(models.Expense.amount).desc())
        .all()
    )

    return {
        "total_spending": float(total_spending or 0),
        "expense_count": expense_count,
        "flagged_count": flagged_count,
        "category_totals": [
            {
                "category_id": row.category_id,
                "category_name": row.category_name,
                "total": float(row.total or 0),
            }
            for row in category_totals
        ],
    }


# ---------------- CATEGORIES ----------------

@app.get("/api/v1/categories")
def get_categories(
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    categories = (
        db.query(models.Category)
        .order_by(models.Category.name)
        .all()
    )

    return [
        {"id": category.id, "name": category.name}
        for category in categories
    ]


@app.post("/api/v1/categories/seed")
def seed_categories(
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    default_categories = [
        "Food",
        "Transport",
        "Shopping",
        "Bills",
        "Health",
        "Entertainment",
        "Education",
        "Other",
    ]

    for name in default_categories:
        existing = (
            db.query(models.Category)
            .filter(
                func.lower(models.Category.name) == name.lower()
            )
            .first()
        )

        if not existing:
            db.add(models.Category(name=name))

    db.commit()

    return {"message": "Default categories checked successfully"}


# ---------------- ANOMALY DETECTION ----------------

def detect_anomalies(
    db: Session,
    user_id: int,
    category,
    amount: float,
    description: str,
    expense_date,
):
    reasons = []

    category_id = category.id
    category_name = category.name.strip()

    # Category-specific daily spending limit.
    if category_name.lower() == "health":
        daily_limit = 10000
    else:
        daily_limit = 2000

    # Get existing spending for this user, category and date.
    daily_total = (
        db.query(
            func.coalesce(func.sum(models.Expense.amount), 0)
        )
        .filter(
            models.Expense.user_id == user_id,
            models.Expense.category_id == category_id,
            models.Expense.expense_date == expense_date,
        )
        .scalar()
    )

    daily_total = float(daily_total or 0)
    projected_total = daily_total + amount

    # Rule 1: Cumulative daily category spending.
    if projected_total > daily_limit:
        reasons.append(
            f"Daily {category_name} spending would reach "
            f"₹{projected_total:,.2f}, exceeding the "
            f"₹{daily_limit:,} limit"
        )

    # Rule 2: A single expense consumes at least 80% of
    # the category's daily limit.
    if amount >= daily_limit * 0.80:
        reasons.append(
            f"This expense uses at least 80% of the "
            f"₹{daily_limit:,} daily {category_name} limit"
        )

    # Rule 3: Exact duplicate: same user, category, amount,
    # description and date.
    duplicate = (
        db.query(models.Expense)
        .filter(
            models.Expense.user_id == user_id,
            models.Expense.category_id == category_id,
            models.Expense.amount == amount,
            models.Expense.description == description,
            models.Expense.expense_date == expense_date,
        )
        .first()
    )

    if duplicate:
        reasons.append(
            "Possible duplicate expense with the same "
            "description, amount, category and date"
        )

    # Rule 4: Repeated amount in the same category and date.
    # This catches repeated amounts even if descriptions differ.
    repeated_expense = (
        db.query(models.Expense)
        .filter(
            models.Expense.user_id == user_id,
            models.Expense.category_id == category_id,
            models.Expense.expense_date == expense_date,
            models.Expense.amount.between(
                amount - 0.01,
                amount + 0.01,
            ),
        )
        .first()
    )

    if repeated_expense:
        reasons.append(
            f"Repeated {category_name} expense of "
            f"approximately ₹{amount:,.2f} on the same day"
        )

    # Rule 5: Compare with the user's previous 30-day
    # category spending. Require at least five past expenses.
    history_start = expense_date - timedelta(days=30)

    historical_amounts = (
        db.query(models.Expense.amount)
        .filter(
            models.Expense.user_id == user_id,
            models.Expense.category_id == category_id,
            models.Expense.expense_date >= history_start,
            models.Expense.expense_date < expense_date,
        )
        .all()
    )

    previous_amounts = [
        float(row[0])
        for row in historical_amounts
    ]

    if len(previous_amounts) >= 5:
        average_amount = (
            sum(previous_amounts) / len(previous_amounts)
        )

        if (
            average_amount > 0
            and amount > average_amount * 3
            and amount > average_amount + 500
        ):
            reasons.append(
                f"Unusually high {category_name} expense "
                f"compared with your recent average of "
                f"₹{average_amount:,.2f}"
            )

    return reasons


# ---------------- ADD EXPENSE ----------------

@app.post("/api/v1/expenses")
def create_expense(
    expense_data: ExpenseCreate,
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    category = (
        db.query(models.Category)
        .filter(
            models.Category.id == expense_data.category_id
        )
        .first()
    )

    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Expense category not found",
        )

    description = expense_data.description.strip()

    if not description:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Description cannot be empty",
        )

    reasons = detect_anomalies(
        db=db,
        user_id=user.id,
        category=category,
        amount=expense_data.amount,
        description=description,
        expense_date=expense_data.expense_date,
    )

    expense = models.Expense(
        amount=expense_data.amount,
        category_id=category.id,
        description=description,
        expense_date=expense_data.expense_date,
        user_id=user.id,
        is_flagged=bool(reasons),
        anomaly_reasons=json.dumps(reasons),
    )

    db.add(expense)
    db.commit()
    db.refresh(expense)

    return {
        "id": expense.id,
        "amount": expense.amount,
        "description": expense.description,
        "expense_date": expense.expense_date,
        "category_id": expense.category_id,
        "category_name": category.name,
        "is_flagged": expense.is_flagged,
        "anomaly_reasons": reasons,
    }


# ---------------- VIEW TRANSACTIONS ----------------

def parse_anomaly_reasons(value):
    """Read both JSON-formatted and legacy plain-text reasons."""
    if not value:
        return []

    try:
        parsed = json.loads(value)

        if isinstance(parsed, list):
            return [str(reason) for reason in parsed]

        if isinstance(parsed, str):
            return [parsed] if parsed else []

        return [str(parsed)]

    except (json.JSONDecodeError, TypeError):
        # Old records may contain plain text instead of JSON.
        return [value]


@app.get("/api/v1/expenses")
def get_expenses(
    user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    expenses = (
        db.query(models.Expense)
        .filter(models.Expense.user_id == user.id)
        .order_by(
            models.Expense.expense_date.desc(),
            models.Expense.id.desc(),
        )
        .all()
    )

    return [
        {
            "id": expense.id,
            "amount": expense.amount,
            "description": expense.description,
            "expense_date": expense.expense_date,
            "category_id": expense.category_id,
            "category_name": expense.category.name,
            "is_flagged": expense.is_flagged,
            "anomaly_reasons": parse_anomaly_reasons(
                expense.anomaly_reasons
            ),
        }
        for expense in expenses
    ]
